package tech.luau.smartiot;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

/**
 *
 */
@ApplicationPath("/data")

public class SmartiotRestApplication extends Application {
}
